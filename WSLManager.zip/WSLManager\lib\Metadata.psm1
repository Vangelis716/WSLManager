﻿# Display names, descriptions, cached OS info and resource profiles, stored as JSON keyed by distro GUID.
# Reserved keys: "_settings" (manager settings) and "_pending" (metadata for instances still being created, keyed by name).

$script:MetaPath = 'D:\WSL\wslmanager.json'
$script:Meta = $null

function ConvertTo-Hashtable($InputObject) {
    if ($null -eq $InputObject) { return $null }
    if ($InputObject -is [System.Management.Automation.PSCustomObject]) {
        $h = @{}
        foreach ($p in $InputObject.PSObject.Properties) { $h[$p.Name] = ConvertTo-Hashtable $p.Value }
        return $h
    }
    if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
        return , @($InputObject | ForEach-Object { ConvertTo-Hashtable $_ })
    }
    $InputObject
}

function Initialize-Metadata {
    param([string]$Path = $script:MetaPath)
    $script:MetaPath = $Path
    $script:Meta = @{}
    if (Test-Path -LiteralPath $Path) {
        $json = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
        if ($json.Trim()) { $script:Meta = ConvertTo-Hashtable ($json | ConvertFrom-Json) }
    }
    foreach ($k in '_settings', '_pending') { if (-not $script:Meta.ContainsKey($k)) { $script:Meta[$k] = @{} } }
}

function Save-Metadata {
    $dir = Split-Path $script:MetaPath
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    if (Test-Path -LiteralPath $script:MetaPath) { Copy-Item -LiteralPath $script:MetaPath "$script:MetaPath.bak" -Force }
    $json = $script:Meta | ConvertTo-Json -Depth 10
    [IO.File]::WriteAllText($script:MetaPath, $json, (New-Object Text.UTF8Encoding $false))
}

function Get-InstanceMeta {
    param([Parameter(Mandatory)][string]$Guid)
    $m = $script:Meta[$Guid]
    if (-not $m) { $m = @{} }
    @{
        displayName = $m['displayName']
        description = $m['description']
        os          = $m['os']
        resources   = $m['resources']
    }
}

function Set-InstanceMeta {
    <# Merges the given keys into the instance's metadata and saves. #>
    param([Parameter(Mandatory)][string]$Guid, [Parameter(Mandatory)][hashtable]$Values)
    if (-not $script:Meta.ContainsKey($Guid)) { $script:Meta[$Guid] = @{ created = (Get-Date).ToString('s') } }
    foreach ($k in $Values.Keys) { $script:Meta[$Guid][$k] = $Values[$k] }
    Save-Metadata
}

function Remove-InstanceMeta {
    param([Parameter(Mandatory)][string]$Guid)
    if ($script:Meta.ContainsKey($Guid)) { $script:Meta.Remove($Guid); Save-Metadata }
}

function Get-ManagerSetting {
    param([Parameter(Mandatory)][string]$Name)
    $script:Meta['_settings'][$Name]
}

function Set-ManagerSetting {
    param([Parameter(Mandatory)][string]$Name, $Value)
    $script:Meta['_settings'][$Name] = $Value
    Save-Metadata
}

function Add-PendingMeta {
    <# Remembers metadata for an instance that does not have a GUID yet (still installing). #>
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][hashtable]$Values)
    $script:Meta['_pending'][$Name] = $Values
    Save-Metadata
}

function Remove-PendingMeta {
    param([Parameter(Mandatory)][string]$Name)
    if ($script:Meta['_pending'].ContainsKey($Name)) { $script:Meta['_pending'].Remove($Name); Save-Metadata }
}

function Resolve-PendingMeta {
    <# Attaches pending metadata to instances that now exist. #>
    param([object[]]$Instances)
    $pending = $script:Meta['_pending']
    foreach ($name in @($pending.Keys)) {
        $inst = $Instances | Where-Object Name -eq $name | Select-Object -First 1
        if ($inst) {
            $values = $pending[$name]
            $pending.Remove($name)
            Set-InstanceMeta -Guid $inst.Guid -Values $values
        }
    }
}

Export-ModuleMember -Function Initialize-Metadata, Save-Metadata, Get-InstanceMeta, Set-InstanceMeta, Remove-InstanceMeta,
    Get-ManagerSetting, Set-ManagerSetting, Add-PendingMeta, Remove-PendingMeta, Resolve-PendingMeta
