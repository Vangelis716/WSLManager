﻿# Reads/writes the VM resource keys (processors, memory, swap) in %USERPROFILE%\.wslconfig,
# leaving every other line (comments, networkingMode, other sections) untouched.

$script:ConfigPath = Join-Path $env:USERPROFILE '.wslconfig'
$script:ProfileKeys = 'processors', 'memory', 'swap'

function Get-WslConfigProfile {
    $result = @{ processors = $null; memory = $null; swap = $null }
    if (-not (Test-Path -LiteralPath $script:ConfigPath)) { return $result }
    $section = ''
    foreach ($line in Get-Content -LiteralPath $script:ConfigPath) {
        if ($line -match '^\s*\[(.+?)\]') { $section = $Matches[1].Trim().ToLower(); continue }
        if ($section -eq 'wsl2' -and $line -match '^\s*([A-Za-z]+)\s*=\s*([^#]*)') {
            $key = $Matches[1].ToLower()
            if ($script:ProfileKeys -contains $key) { $result[$key] = $Matches[2].Trim().Trim('"') }
        }
    }
    $result
}

function Set-WslConfigProfile {
    <# Writes processors/memory/swap under [wsl2]. A $null/empty value removes the key (WSL default). #>
    param([Parameter(Mandatory)][hashtable]$Resources)
    $lines = New-Object System.Collections.Generic.List[string]
    if (Test-Path -LiteralPath $script:ConfigPath) {
        Copy-Item -LiteralPath $script:ConfigPath "$script:ConfigPath.bak" -Force
        foreach ($l in Get-Content -LiteralPath $script:ConfigPath) { $lines.Add($l) }
    }

    $start = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*\[\s*wsl2\s*\]') { $start = $i; break }
    }
    if ($start -lt 0) {
        if ($lines.Count -and $lines[$lines.Count - 1].Trim()) { $lines.Add('') }
        $lines.Add('[wsl2]')
        $start = $lines.Count - 1
    }

    foreach ($key in $script:ProfileKeys) {
        $value = $Resources[$key]
        $end = $lines.Count
        for ($i = $start + 1; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*\[') { $end = $i; break } }
        $found = -1
        for ($i = $start + 1; $i -lt $end; $i++) { if ($lines[$i] -match "^\s*$key\s*=") { $found = $i; break } }

        if ([string]::IsNullOrWhiteSpace([string]$value)) {
            if ($found -ge 0) { $lines.RemoveAt($found) }
        } elseif ($found -ge 0) {
            $lines[$found] = "$key=$value"
        } else {
            # insert after the last non-blank line of the section
            $insert = $end
            while ($insert - 1 -gt $start -and -not $lines[$insert - 1].Trim()) { $insert-- }
            $lines.Insert($insert, "$key=$value")
        }
    }
    [IO.File]::WriteAllText($script:ConfigPath, (($lines -join "`r`n") + "`r`n"), (New-Object Text.UTF8Encoding $false))
}

function ConvertTo-Bytes([string]$Value) {
    if ($Value -match '^\s*(\d+(?:\.\d+)?)\s*([KMGT]?B?)\s*$') {
        $mult = switch ($Matches[2].ToUpper().TrimEnd('B')) { 'K' { 1KB } 'M' { 1MB } 'G' { 1GB } 'T' { 1TB } default { 1 } }
        return [int64]([double]$Matches[1] * $mult)
    }
    $null
}

function Test-ProfileEqual([hashtable]$A, [hashtable]$B) {
    foreach ($key in $script:ProfileKeys) {
        $x = [string]$A[$key]; $y = [string]$B[$key]
        if ($key -ne 'processors') { $x = ConvertTo-Bytes $x; $y = ConvertTo-Bytes $y }
        if ("$x" -ne "$y") { return $false }
    }
    $true
}

function Format-Profile([hashtable]$Resources) {
    if (-not $Resources) { return '' }
    $cpu = if ($Resources.processors) { "$($Resources.processors) CPU" } else { 'all CPU' }
    $mem = if ($Resources.memory) { "$($Resources.memory) RAM" } else { 'default RAM' }
    $swap = if ($Resources.swap) { "$($Resources.swap) swap" } else { 'default swap' }
    "$cpu / $mem / $swap"
}

function Test-ProfileValues {
    <# Returns an error message, or $null when the values are valid. Empty values are allowed. #>
    param([hashtable]$Resources)
    $cpu = [string]$Resources.processors
    if ($cpu) {
        $n = 0
        if (-not [int]::TryParse($cpu, [ref]$n) -or $n -lt 1 -or $n -gt [Environment]::ProcessorCount) {
            return "CPU must be a whole number between 1 and $([Environment]::ProcessorCount)."
        }
    }
    $ram = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
    foreach ($key in 'memory', 'swap') {
        $v = [string]$Resources[$key]
        if (-not $v) { continue }
        if ($v -notmatch '^(0|\d+(\.\d+)?(MB|GB|TB))$') { return "$key must look like 512MB or 8GB." }
        if ($key -eq 'memory' -and (ConvertTo-Bytes $v) -gt $ram) {
            return "Memory exceeds physical RAM ($([math]::Round($ram / 1GB)) GB)."
        }
    }
    $null
}

Export-ModuleMember -Function Get-WslConfigProfile, Set-WslConfigProfile, ConvertTo-Bytes, Test-ProfileEqual, Format-Profile, Test-ProfileValues
