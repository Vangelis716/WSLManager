﻿# Wrappers around wsl.exe and the Lxss registry key.

$script:LxssKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss'

function Get-WslExePath {
    if ([Environment]::Is64BitProcess) { Join-Path $env:SystemRoot 'System32\wsl.exe' }
    else { Join-Path $env:SystemRoot 'Sysnative\wsl.exe' }
}

function ConvertTo-ProcessArgument([string]$Value) {
    if ($Value -eq '') { return '""' }
    if ($Value -notmatch '[\s"]') { return $Value }
    '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function Invoke-Wsl {
    <# Runs wsl.exe with UTF-8 output and returns ExitCode/Output/Error. Throws on failure unless -AllowFailure. #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]]$Arguments,
        [switch]$AllowFailure
    )
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = Get-WslExePath
    $psi.Arguments = ($Arguments | ForEach-Object { ConvertTo-ProcessArgument $_ }) -join ' '
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [Text.Encoding]::UTF8
    $psi.EnvironmentVariables['WSL_UTF8'] = '1'

    $proc = [Diagnostics.Process]::Start($psi)
    $outTask = $proc.StandardOutput.ReadToEndAsync()
    $errTask = $proc.StandardError.ReadToEndAsync()
    $proc.WaitForExit()

    $result = [pscustomobject]@{
        ExitCode = $proc.ExitCode
        Output   = ($outTask.Result -replace "`0", '').TrimEnd()
        Error    = ($errTask.Result -replace "`0", '').TrimEnd()
    }
    if ($result.ExitCode -ne 0 -and -not $AllowFailure) {
        $detail = (@($result.Error, $result.Output) | Where-Object { $_ }) -join ' '
        throw "wsl $($psi.Arguments) failed (exit $($result.ExitCode)): $detail"
    }
    $result
}

function Get-WslState {
    <# Returns a hashtable of distro name -> state (Running/Stopped/Installing/...). #>
    $r = Invoke-Wsl -Arguments '--list', '--verbose' -AllowFailure
    $map = @{}
    foreach ($line in ($r.Output -split "`r?`n")) {
        if ($line -match '^\s*\*?\s*(\S+)\s+(\S+)\s+(\d+)\s*$') { $map[$Matches[1]] = $Matches[2] }
    }
    $map
}

function Get-WslInstance {
    if (-not (Test-Path $script:LxssKey)) { return }
    $default = (Get-ItemProperty $script:LxssKey -ErrorAction SilentlyContinue).DefaultDistribution
    $states = Get-WslState
    foreach ($key in Get-ChildItem $script:LxssKey) {
        $p = Get-ItemProperty $key.PSPath
        if (-not $p.DistributionName) { continue }
        $basePath = ([string]$p.BasePath) -replace '^\\\\\?\\', ''
        $vhdName = if ($p.PSObject.Properties['VhdFileName']) { $p.VhdFileName } else { 'ext4.vhdx' }
        $vhdPath = Join-Path $basePath $vhdName
        $vhdSize = if (Test-Path -LiteralPath $vhdPath) { (Get-Item -LiteralPath $vhdPath).Length } else { $null }
        $state = if ($states.ContainsKey($p.DistributionName)) { $states[$p.DistributionName] } else { 'Stopped' }
        [pscustomobject]@{
            Guid       = $key.PSChildName
            Name       = $p.DistributionName
            BasePath   = $basePath
            VhdPath    = $vhdPath
            VhdSize    = $vhdSize
            Version    = $p.Version
            DefaultUid = $p.DefaultUid
            IsDefault  = ($key.PSChildName -eq $default)
            State      = $state
        }
    }
}

function Get-WslOsInfo {
    <# Reads /etc/os-release and kernel version. Boots the distro if it is stopped. #>
    param([Parameter(Mandatory)][string]$Name)
    $r = Invoke-Wsl -Arguments '-d', $Name, '--exec', 'cat', '/etc/os-release'
    $os = @{}
    foreach ($line in ($r.Output -split "`r?`n")) {
        if ($line -match '^([A-Z_]+)=(.*)$') { $os[$Matches[1]] = $Matches[2].Trim('"', "'") }
    }
    $kernel = (Invoke-Wsl -Arguments '-d', $Name, '--exec', 'uname', '-r' -AllowFailure).Output
    $pretty = if ($os['PRETTY_NAME']) { $os['PRETTY_NAME'] } else { "$($os['NAME']) $($os['VERSION'])".Trim() }
    @{
        pretty    = $pretty
        id        = $os['ID']
        versionId = $os['VERSION_ID']
        kernel    = $kernel
        checked   = (Get-Date).ToString('s')
    }
}

function Start-WslInstance {
    <# Starts a hidden keep-alive process so the distro does not idle-stop. #>
    param([Parameter(Mandatory)][string]$Name)
    Start-Process -FilePath (Get-WslExePath) -ArgumentList '-d', $Name, '--exec', 'sleep', '2147483647' -WindowStyle Hidden
}

function Stop-WslInstance {
    param([Parameter(Mandatory)][string]$Name)
    Invoke-Wsl -Arguments '--terminate', $Name | Out-Null
}

function Stop-WslAll {
    Invoke-Wsl -Arguments '--shutdown' | Out-Null
}

function Open-WslTerminal {
    param([Parameter(Mandatory)][string]$Name)
    if (Get-Command wt.exe -ErrorAction SilentlyContinue) {
        Start-Process wt.exe -ArgumentList 'new-tab', '--title', $Name, 'wsl.exe', '-d', $Name, '--cd', '~'
    } else {
        Start-Process (Get-WslExePath) -ArgumentList '-d', $Name, '--cd', '~'
    }
}

function Set-WslDefault {
    param([Parameter(Mandatory)][string]$Name)
    Invoke-Wsl -Arguments '--set-default', $Name | Out-Null
}

function Get-WslOnlineList {
    $r = Invoke-Wsl -Arguments '--list', '--online'
    $inTable = $false
    foreach ($line in ($r.Output -split "`r?`n")) {
        if (-not $inTable) { if ($line -match '^NAME\s+') { $inTable = $true }; continue }
        if ($line -match '^(\S+)\s{2,}(.+?)\s*$') {
            [pscustomobject]@{ Name = $Matches[1]; FriendlyName = $Matches[2] }
        }
    }
}

function New-WslFromOnline {
    <# Installs in a visible console so the distro's first-run user setup can be completed there. #>
    param(
        [Parameter(Mandatory)][string]$Distro,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Location
    )
    Start-Process (Get-WslExePath) -ArgumentList '--install', $Distro, '--name', $Name, '--location', (ConvertTo-ProcessArgument $Location)
}

function New-WslClone {
    <# Exports the source as VHD straight into the new folder and registers it in place (one copy only). #>
    param(
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Location
    )
    if ((Test-Path -LiteralPath $Location) -and (Get-ChildItem -LiteralPath $Location -Force)) {
        throw "Target folder '$Location' already exists and is not empty."
    }
    New-Item -ItemType Directory -Force -Path $Location | Out-Null
    $vhd = Join-Path $Location 'ext4.vhdx'
    try {
        Invoke-Wsl -Arguments '--export', $Source, $vhd, '--format', 'vhd' | Out-Null
        Invoke-Wsl -Arguments '--import-in-place', $Name, $vhd | Out-Null
    } catch {
        Remove-Item -LiteralPath $vhd -Force -ErrorAction SilentlyContinue
        throw
    }
    $src = Get-WslInstance | Where-Object Name -eq $Source
    $new = Get-WslInstance | Where-Object Name -eq $Name
    if ($src -and $new -and $null -ne $src.DefaultUid) {
        Set-ItemProperty -Path "$script:LxssKey\$($new.Guid)" -Name DefaultUid -Value $src.DefaultUid
    }
    $new
}

function Register-WslVhdx {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Path,
        [string]$DefaultUser
    )
    Invoke-Wsl -Arguments '--import-in-place', $Name, $Path | Out-Null
    if ($DefaultUser) { Invoke-Wsl -Arguments '--manage', $Name, '--set-default-user', $DefaultUser | Out-Null }
    Get-WslInstance | Where-Object Name -eq $Name
}

function Remove-WslInstance {
    param([Parameter(Mandatory)][string]$Name)
    Invoke-Wsl -Arguments '--unregister', $Name | Out-Null
}

function Rename-WslInstance {
    <# Renames the distro in the registry. Returns $true if wsl.exe already reports the new name. #>
    param(
        [Parameter(Mandatory)][string]$Guid,
        [Parameter(Mandatory)][string]$NewName
    )
    Set-ItemProperty -Path "$script:LxssKey\$Guid" -Name DistributionName -Value $NewName
    $names = (Invoke-Wsl -Arguments '--list', '--quiet' -AllowFailure).Output -split "`r?`n" | ForEach-Object { $_.Trim() }
    $names -contains $NewName
}

function Resize-WslDisk {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Size
    )
    Invoke-Wsl -Arguments '--manage', $Name, '--resize', $Size | Out-Null
}

Export-ModuleMember -Function Invoke-Wsl, Get-WslState, Get-WslInstance, Get-WslOsInfo, Start-WslInstance,
    Stop-WslInstance, Stop-WslAll, Open-WslTerminal, Set-WslDefault, Get-WslOnlineList, New-WslFromOnline,
    New-WslClone, Register-WslVhdx, Remove-WslInstance, Rename-WslInstance, Resize-WslDisk, ConvertTo-ProcessArgument
